//Aufgabe: Abschlussaufgabe
//Name: Kristina Novikov
//Matrikel: 254136
//Datum: 10.02.2018
//Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.


namespace Abschlussaufgabe {

    export class Shooter extends MovingObjects {
        width: number;

        constructor(_x: number, _y: number) {
            super(_x, _y);
            this.width = 90;
            this.height = 450;
        }

        move(): void {
//            if (rightKey == true && this.x + this.width < 550) {
//                this.x += 5;
//            }
//            else if (leftKey == true && this.x + this.width > -160) {
//                this.x -= 5;
//            }
        }

        draw(): void {
            crc2.globalAlpha = 1;
            crc2.beginPath();
            crc2.rect(this.x + 250, this.y + 60, 90, 40);
            crc2.strokeStyle = "#151515";
            crc2.fillStyle = "#151515";
            crc2.stroke();
            crc2.fill();
            crc2.closePath();
        }

    }
}