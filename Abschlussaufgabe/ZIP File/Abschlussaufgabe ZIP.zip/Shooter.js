//Aufgabe: Abschlussaufgabe
//Name: Kristina Novikov
//Matrikel: 254136
//Datum: 10.02.2018
//Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.
var Abschlussaufgabe;
(function (Abschlussaufgabe) {
    class Shooter extends Abschlussaufgabe.MovingObjects {
        constructor(_x, _y) {
            super(_x, _y);
            this.width = 90;
            this.height = 450;
        }
        move() {
            //            if (rightKey == true && this.x + this.width < 550) {
            //                this.x += 5;
            //            }
            //            else if (leftKey == true && this.x + this.width > -160) {
            //                this.x -= 5;
            //            }
        }
        draw() {
            Abschlussaufgabe.crc2.globalAlpha = 1;
            Abschlussaufgabe.crc2.beginPath();
            Abschlussaufgabe.crc2.rect(this.x + 250, this.y + 60, 90, 40);
            Abschlussaufgabe.crc2.strokeStyle = "#151515";
            Abschlussaufgabe.crc2.fillStyle = "#151515";
            Abschlussaufgabe.crc2.stroke();
            Abschlussaufgabe.crc2.fill();
            Abschlussaufgabe.crc2.closePath();
        }
    }
    Abschlussaufgabe.Shooter = Shooter;
})(Abschlussaufgabe || (Abschlussaufgabe = {}));
//# sourceMappingURL=Shooter.js.map